# COT Dashboard v3 — Power BI Edition

A multi-color, role-based analytics dashboard with light/dark themes, dd-mm-yyyy dates, and admin-only back-date editing. Free to host. Built for beginners.

---

## ✨ What's new in v3

| Change | Status |
|---|---|
| 🎨 **Power BI–style multi-color visuals** | ✅ |
| 🌗 **Light/Dark theme toggle** (top right, 🌙/☀️ button) | ✅ |
| 📅 **Indian date format** (dd-mm-yyyy everywhere) | ✅ |
| ➗ **"Average" excludes blanks AND zeros** (your new definition) | ✅ |
| ❌ **Removed "Weighted Average"** | ✅ |
| 👥 **Plant users no longer see Upload/Edit buttons** (cleanly hidden) | ✅ |
| ⚙ **Separate "Back-Date Editor" tab** for COT Admin only | ✅ |
| 📥 **Custom Export** for any plant/equipment/date range | ✅ |
| 📋 **Audit log** for all back-date modifications | ✅ |
| 🏷️ **Status indicators** in records table (BLANK / ZERO / valid) | ✅ |

---

## 📦 Files in this package

```
cot-dashboard/
├── login.html                  ← Sign-in page (Power BI style)
├── dashboard.html              ← Main dashboard with 3 tabs
├── COT_Data_Template.xlsx      ← Excel template for your team
└── data/                       ← 17 sample CSV files
    ├── biscuit_wtp_pump_b1.csv
    ├── biscuit_steam_boiler1.csv
    └── ... (15 more)
```

---

## ▶️ Test locally first (1 minute)

1. Unzip everything.
2. Double-click `login.html`.
3. Try each role:
   - `admin` / `admin123` → all 3 tabs visible (Dashboard, Export, Back-Date Editor)
   - `cotuser` / `cot123` → 2 tabs (Dashboard, Export); can upload
   - `biscuit` / `biscuit123` → 2 tabs (Dashboard, Export); cannot upload
4. Click the 🌙 button (top right) to toggle dark mode.
5. In sidebar: **Biscuit → WTP → Process Water → Pump B1** → see the live charts.
6. Change Date Range and Aggregation → numbers update instantly.

---

## 🌐 Deploy to GitHub Pages (replace your existing files)

1. Go to **github.com/pranavdhiman102/Trial-dashboard-2**
2. Click each old file → trash icon → confirm delete:
   - Old `login.html`
   - Old `dashboard.html`
   - Old `data` folder
   - Old `COT_Data_Template.xlsx` if present
3. Click **"Add file" → "Upload files"**
4. Drag in: `login.html`, `dashboard.html`, `COT_Data_Template.xlsx`, and the entire `data` folder
5. Commit changes
6. Wait 60 seconds → refresh **https://pranavdhiman102.github.io/Trial-dashboard-2/login.html**

---

## 🎛️ The 3 tabs explained

### Tab 1 — Dashboard (everyone)
- KPI cards (4 colored): Selected aggregation, Sum, Average, Min/Max
- Daily Trend (blue line)
- Distribution histogram (orange)
- Month-wise (teal)
- Day-of-Week pattern (purple)
- This vs Prior Period (pink)
- Recent records table with status flags

### Tab 2 — Export Data (everyone with export rights)
- Pick any **plant → area → sub-area → equipment** independently
- Pick **any date range** (no restriction)
- Download as Excel or CSV
- Preview first 10 rows before downloading

### Tab 3 — Back-Date Editor (COT Admin ONLY — completely hidden for others)
- Edit historical records of any equipment
- Mandatory "reason for change" field
- Audit trail shows every change in this session
- Recent 30 records preview for the selected equipment

---

## 👥 Login map

| Login | Password | Tab 1 Dashboard | Tab 2 Export | Tab 3 Back-Date | Upload Excel |
|---|---|:---:|:---:|:---:|:---:|
| `admin` / `admin123` | COT Admin | ✓ all plants | ✓ all plants | ✓ | ✓ |
| `cotuser` / `cot123` | COT User | ✓ all plants | ✓ all plants | ✗ hidden | ✓ |
| `pcpb` / `pcpb123` | PCPB Plant | ✓ PCPB only | ✓ PCPB only | ✗ hidden | ✗ hidden |
| `snacks` / `snacks123` | Snacks & Noodles | ✓ Snacks only | ✓ Snacks only | ✗ hidden | ✗ hidden |
| `biscuit` / `biscuit123` | Biscuit Plant | ✓ Biscuit only | ✓ Biscuit only | ✗ hidden | ✗ hidden |
| `ppb` / `ppb123` | PPB Plant | ✓ PPB only | ✓ PPB only | ✗ hidden | ✗ hidden |

---

## 📊 Data format (simple, fixed)

Every equipment file has **only 2 columns**:

| Date | Value |
|---|---|
| 01-04-2026 | 124.50 |
| 02-04-2026 |   |
| 03-04-2026 | 0 |
| 04-04-2026 | 132.80 |

- **Date** = `dd-mm-yyyy` (Indian format, mandatory)
- **Value** = number, blank, or 0
- **Blank cells** = no reading taken → ignored in Average/Median/Min
- **Zero (0)** = equipment off → ignored in Average/Median/Min, included in Sum/Max
- The dashboard's Recent Records table flags each row clearly

---

## ⚠️ Important: Storage limitation

This version still uses **static CSV files** in your GitHub repo.

When users click "Upload Excel":
- ✅ The data is loaded and shown live in their browser
- ❌ The data is NOT saved permanently — it disappears when they close the tab
- ❌ Other users can't see what they uploaded

**The next message will fix this.** I'll send you the Google Sheets storage setup guide so uploads persist forever and the entire team sees the same data.

For now, this version is perfect for:
- Testing the new visuals and role-based access
- Showing your team what the final product will look like
- Confirming you're happy with the design before adding storage

---

## ➕ Customizing the hierarchy

Open `dashboard.html` in Notepad. Find `const HIERARCHY = {` (around line 480). Add/remove equipment by following the existing pattern. Save the file → push to GitHub → done.

Each equipment line maps to a CSV file like:
```javascript
'Pump B1': 'data/biscuit_wtp_pump_b1.csv'
```

If the CSV doesn't exist yet, the dashboard auto-generates **365 days of sample data** for that equipment so the demo never breaks.

---

## 🔧 Troubleshooting

| Problem | Fix |
|---|---|
| Dark mode looks weird after switching | Refresh the page once (charts re-render) |
| 404 on the GitHub link | Wait 2 min, GitHub Pages takes time to rebuild |
| Buttons missing for plant user | That's correct — they're intentionally hidden |
| "Back-Date Editor" tab missing | You must be logged in as `admin` |
| Data shows zero on dashboard | Check your CSV — Date format must be `dd-mm-yyyy` |
| Custom date range shows nothing | Both Start and End must be filled in |

---

## 🚦 What's next

✅ Send a screenshot or "looks good" — I'll send the **Google Sheets storage guide** in the next message.

This will:
- Save uploaded data permanently (forever, free)
- Make all 15 users see the same data
- Track who uploaded what and when
- Survive any browser closing or computer restart

Ready when you are. 🚀
